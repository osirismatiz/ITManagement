Set-ExecutionPolicy -ExecutionPolicy RemoteSigned -Force
Get-ExecutionPolicy

[System.GC]::Collect()
Clear-Host

$SCRIPTNAME = $MyInvocation.MyCommand.Name
$host.ui.rawui.windowtitle = $SCRIPTNAME

$CURRENTFOLDER = Split-Path -parent $MyInvocation.MyCommand.Path
cd $CURRENTFOLDER

Write-Host "`r`nInstall GAC" -Fore blue -Back yellow
get-childitem -path "..\Assembly" -filter *.dll | foreach-object { ..\Tools\gacutil.exe -if $_.FullName }
