Set-ExecutionPolicy -ExecutionPolicy RemoteSigned -Force
Get-ExecutionPolicy

[System.GC]::Collect()
Clear-Host

$SCRIPTNAME = $MyInvocation.MyCommand.Name
$host.ui.rawui.windowtitle = $SCRIPTNAME

$CURRENTFOLDER = Split-Path -parent $MyInvocation.MyCommand.Path
cd $CURRENTFOLDER


if (!(test-path "F:\Projects\GlobalBank.ESB\FileDrop"))
{
	New-Item -ItemType "directory" -Path "F:\Projects\GlobalBank.ESB\FileDrop" -Force 
	Copy-Item "F:\Projects\Microsoft.Practices.ESB\Source\Samples\Exception Handling\Test\Filedrop\*" -Destination "F:\Projects\GlobalBank.ESB\FileDrop" -Recurse -Force 	
}
	Copy-Item "F:\Projects\Microsoft.Practices.ESB\Source\Samples\Exception Handling\Test\Data\Request_GoodApproved.xml" -Destination "F:\Projects\GlobalBank.ESB\FileDrop" -Force 
	Copy-Item "F:\Projects\Microsoft.Practices.ESB\Source\Samples\Exception Handling\Test\Data\Request_Bad_ReqID_9999.xml" -Destination "F:\Projects\GlobalBank.ESB\FileDrop" -Force 
	
$ipAddress = (ipconfig)-like'*IPv4*'|%{($_-split': ')[-1]}
$ipAddress

#F:\Projects\Microsoft.Practices.ESB\Source\Samples\Exception Handling\Test\Filedrop

#ACEINA\GRP_LA_PPT_BTS Administrators
#ACEINA\GRP_LA_PPT_BTS App Users
#ACEINA\GRP_LA_PPT_BTS Operators

