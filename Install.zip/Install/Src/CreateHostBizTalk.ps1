<#
    Date       : 2019-03-07
    Author     : Osiris Matiz Zapata
    Name       : ChangeServicePassword
    Description: Change passwords to all services list 
#>

Set-ExecutionPolicy -ExecutionPolicy RemoteSigned -Force
Get-ExecutionPolicy

[System.GC]::Collect()
Clear-Host

$SCRIPTNAME = $MyInvocation.MyCommand.Name
$host.ui.rawui.windowtitle = $SCRIPTNAME

$CURRENTFOLDER = Split-Path -parent $MyInvocation.MyCommand.Path
cd $CURRENTFOLDER

###Import Modules
. ..\Modules\ModuleXML.ps1 
. ..\Modules\ModuleLogs.ps1 
. ..\Modules\ModuleBizTalk.ps1 

WriteLog "INFO" "***** Start Script *****" $SCRIPTNAME
WriteLog "INFO" ("Current Folder is:'{0}'" -f $CURRENTFOLDER) $SCRIPTNAME

function Main{

    try{ 
		$hostList = GetPlatformSettings $CONFIGPLATFORM 

		WriteLog "INFO" "Creating Host Instance" $SCRIPTNAME
		WriteLog "INFO" "---------------------------------------------------------------------------------------------------" $SCRIPTNAME
		
		$hostCredentials = $Host.ui.PromptForCredential("Logon Credentials", "Please insert BizTalk Host user", "DOMAIN\BizTalkHost", "");
		[String]$hostCredentialsPassword = [Runtime.InteropServices.Marshal]::PtrToStringAuto([Runtime.InteropServices.Marshal]::SecureStringToBSTR($hostCredentials.Password)); 
		
		$isoHostCredentials = $Host.ui.PromptForCredential("Logon Credentials", "Please insert BizTalk Isolated Host user", "DOMAIN\BizTalkIsolatedHost", "");
		[String]$isoHostCredentialsPassword = [Runtime.InteropServices.Marshal]::PtrToStringAuto([Runtime.InteropServices.Marshal]::SecureStringToBSTR($isoHostCredentials.Password)); 
		
		[int]$hostTypeInt = 0
		foreach($itemHost in $hostList) {
			[string]$hostName = $itemHost.Node.Name
			[string]$hostType = $itemHost.Node.Type
			if($hostType -eq "In-process") { $hostTypeInt = 1 } else { $hostTypeInt = 2 }
			[string]$windowsGroup = $itemHost.Node.WindowsGroup
			
			[bool]$isTrusted = [System.Convert]::ToBoolean($itemHost.Node.isTrusted)
			[bool]$isTracking = [System.Convert]::ToBoolean($itemHost.Node.isTracking)
			[bool]$is32BitOnly = [System.Convert]::ToBoolean($itemHost.Node.is32BitOnly)
			
			WriteLog "INFO" ("Host name:'{0}' Type:'{1}' isTracking:'{2}' isTrusted:'{3}' is32BitOnly:'{4}'" -f  $hostName, $hostType, $isTracking, $isTrusted, $is32BitOnly) $SCRIPTNAME
			##############################
			# Creating hosts for receiving
			# HostType: Invalid: 0, In-process:	1, Isolated: 2
			#Write-Host $hostName $hostTypeInt $windowsGroup $isTrusted $isTracking $is32BitOnly
			CreateBizTalkHost $hostName $hostTypeInt $windowsGroup $isTrusted $isTracking $is32BitOnly
		}
		
		[string]$userName = ""
		[string]$password = ""
		foreach($itemHost in $hostList) {
			[string]$hostName = $itemHost.Node.Name
			[string]$hostType = $itemHost.Node.Type
			foreach($itemInstance in $itemHost.Node.HostInstances.HostInstance) {
				[string]$ServerName = $itemInstance.ServerName
				
				if($hostType -eq "In-process") { $userName = $hostCredentials.UserName } elseif ($hostType -eq "Isolated") { $userName = $isoHostCredentials.UserName } else { throw WriteLog "ERROR" "Not user found." $SCRIPTNAME; Continue }
				if($hostType -eq "In-process") { $password = $hostCredentialsPassword } elseif ($hostType -eq "Isolated") { $password = $isoHostCredentialsPassword } else { throw WriteLog "ERROR" "Not password found." $SCRIPTNAME; Continue }
				
				# Create a host instances for receiving associated with the previous hosts created
				#Write-Host $hostName $ServerName $userName $password
				CreateBizTalkHostInstance $hostName $ServerName $userName $password
			}
		}

		foreach($itemHost in $hostList) {
			[string]$hostName = $itemHost.Node.Name
			foreach($itemAdapter in $itemHost.Node.Adapters.Adapter) {
				[string]$adapterName = $itemAdapter.Name
				[string]$adapterDir = $itemAdapter.Direction
				
				# Set adapters that should be handled by receiving host instance
				# $adapterName, [string]$direction, [string]$hostName, [string]$originalDefaulHostName, [boolean]$isDefaultHandler, [boolean]$removeOriginalHostInstance)
				#Write-Host $adapterName $adapterDir $hostName "BizTalkServerApplication" $false $false 
				CreateBizTalkAdapterHandler $adapterName $adapterDir $hostName "BizTalkServerApplication" $false $false 
			}
		}
	}
	catch{ 
        $ErrorMessage = $_.Exception.Message
        $FailedItem = $_.Exception.ItemName
		WriteLog "ERROR" "[Main] $FailedItem. The error message was $ErrorMessage" $SCRIPTNAME
	}

	remove-variable * -scope:Global -ErrorAction:SilentlyContinue
}

Main 
WriteLog "INFO" "***** End Script   *****" $SCRIPTNAME
