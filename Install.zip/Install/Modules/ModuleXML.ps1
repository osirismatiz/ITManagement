﻿
function GetConfigContent{
	param([Parameter(Mandatory=$true)][string]$pathConfig)

    Try { 
        [Xml]$xmlContent = [Xml](Get-Content -Path "$pathConfig" -Encoding UTF8)
        Write-Output $xmlContent
    }
    Catch { 
        $ErrorMessage = $_.Exception.Message
        $FailedItem = $_.Exception.ItemName
		WriteLog "ERROR" "GetConfigContent: $FailedItem. The error message was $ErrorMessage" 
    }
}

function GetXmlNodes{
	param([Parameter(Mandatory=$true)][Xml]$xmlDocument, [Parameter(Mandatory=$true)][String]$xPath, [string]$ns)

    $nameSpace = @{tns = $ns}    
    $params = @{ 'Xml' = $xmlDocument; 'XPath' = $xPath }
    if(![string]::IsNullOrEmpty($ns)) { $params.Add('Namespace', $nameSpace) }
    $xmlContent = Select-Xml @params
    
    Write-Output $xmlContent
}
