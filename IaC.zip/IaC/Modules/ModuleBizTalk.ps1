﻿$BIZTALK_ISOLATED_HOST = "BizTalkServerIsolatedHost"
$START_HOST = "Start"
$STOP_HOST = "Stop"
$SYSMGMTASSEMBLYNAME = "System.Management"

$PLATFORMCONFIGPATH = "$CURRENTFOLDER\..\Config\PlatformSettings.config"
$CONFIGPLATFORM = GetConfigContent $PLATFORMCONFIGPATH


function GetBizTalkService{
	param([Parameter(Mandatory=$true)][Xml]$xmlDoc)

    [string]$nameSpace = "http://iac/services"
    [string]$xPath = "/tns:Services/tns:Service[tns:Name[text()='$BIZTALK_APP_SERVICE']]"
    $nodesServices = GetXmlNodes $xmlDoc $xPath $nameSpace
    #$nodesServices | Foreach { Write-Host $_.Node.Name}
    Write-Output $nodesServices
}


function GetPlatformSettings{
	param([Parameter(Mandatory=$true)][Xml]$xmlDoc)

    [string]$nameSpace = "http://iac/platformsettings"
    [string]$xPath = "/tns:PlatformSettings/tns:Hosts/tns:Host"
    $nodeServers = GetXmlNodes $xmlDoc $xPath $nameSpace
    Write-Output $nodeServers
}

function GetBizTalkIsolatedHost{
	param([Parameter(Mandatory=$true)][Xml]$xmlDoc)

    [string]$nameSpace = "http://iac/services"
    [string]$xPath = "/tns:Services/tns:Service[tns:Name[text()='$BIZTALK_ISOLATED_HOST']]"
    $nodesServices = GetXmlNodes $xmlDoc $xPath $nameSpace
    Write-Output $nodesServices
}


function ChangeCredentialsBizTalkHost{
	param([Parameter(Mandatory=$true)][string]$computerName, 
			[Parameter(Mandatory=$true)][string]$ipAdress, 
			[Parameter(Mandatory=$true)][string]$hostUser,
			[Parameter(Mandatory=$true)][string]$hostPass,
			[Parameter(Mandatory=$true)]$winCredentials)
			
	### https://blog.sandro-pereira.com/2012/02/24/change-user-credentials-of-a-biztalk-host-instance-with-powershell/

	$params = @{'Class' = 'MSBTS_HostInstance'; 'ComputerName' = $ipAdress; 'namespace' = 'root/MicrosoftBizTalkServer'; 'Filter' = "NOT name LIKE '%Isolated%'" }
	if($env:computername -ne $computerName) { $params.Add('Credential', $winCredentials) }
	
	try{
		$hostsList = Get-WmiObject @params 
		
		foreach($item in $hostsList)
		{
			[string]$hostName = $item.HostName
			### Must stop the BizTalk Host instance before change it
			if ($item.ServiceState -eq 1) { 
				$changeStatus = $item.Install($hostUser, $hostPass, "true") 
				if($changeStatus.ReturnValue -eq $null) { WriteLog "INFO" "Updated HostInstance '$hostName' with logon '$hostUser' in '$computerName'" $SCRIPTNAME } 					
			}
			else {
				WriteLog "INFO" "Must stop the BizTalk Host instance '$hostName' before change" $SCRIPTNAME
			}
		}	
	}
	catch{
        $ErrorMessage = $_.Exception.Message
        $FailedItem = $_.Exception.ItemName
		WriteLog "ERROR" "[ChangeCredentialsBizTalkHost] $FailedItem. The error message was $ErrorMessage" $SCRIPTNAME
		Continue 
	}

}

function ChangeCredentialsBizTalkIsolatedHost{
	param([Parameter(Mandatory=$true)][string]$computerName, 
			[Parameter(Mandatory=$true)][string]$ipAdress, 
			[Parameter(Mandatory=$true)][string]$hostUser,
			[Parameter(Mandatory=$true)][string]$hostPass,
			[Parameter(Mandatory=$true)]$winCredentials)

	### https://blog.sandro-pereira.com/2012/02/24/change-user-credentials-of-a-biztalk-host-instance-with-powershell

	$params = @{'Class' = 'MSBTS_HostInstance'; 'ComputerName' = $ipAdress; 'namespace' = 'root/MicrosoftBizTalkServer'; 'Filter' = "name LIKE '%Isolated%'" }
	if($env:computername -ne $computerName) { $params.Add('Credential', $winCredentials) }
	
	try{
		$hostsList = Get-WmiObject @params 
		foreach($item in $hostsList)
		{
			[string]$hostName = $item.HostName
			$changeStatus = $item.Install($hostUser, $hostPass, "true") 
			if($changeStatus.ReturnValue -eq $null) { WriteLog "INFO" "Updated HostInstance '$hostName' with logon '$hostUser' in '$computerName'" $SCRIPTNAME } 					
		}	
	}
	catch{
        $ErrorMessage = $_.Exception.Message
        $FailedItem = $_.Exception.ItemName
		WriteLog "ERROR" "[ChangeCredentialsBizTalkIsolatedHost] $FailedItem. The error message was $ErrorMessage" $SCRIPTNAME
		Continue 
	}
}

function ChangeStatusBizTalkHost{
	param([Parameter(Mandatory=$true)][string]$computerName, 
			[Parameter(Mandatory=$true)][string]$ipAdress, 
			[Parameter(Mandatory=$true)][string]$status,
			[Parameter(Mandatory=$true)]$winCredentials)

	### https://blog.sandro-pereira.com/2012/02/24/change-user-credentials-of-a-biztalk-host-instance-with-powershell/

	$params = @{'Class' = 'MSBTS_HostInstance'; 'ComputerName' = $ipAdress; 'namespace' = 'root/MicrosoftBizTalkServer'; 'Filter' = "NOT name LIKE '%Isolated%'" }
	if($env:computername -ne $computerName) { $params.Add('Credential', $winCredentials) }

	try{ 
		$hostsList = Get-WmiObject @params 
		
		foreach($item in $hostsList)
		{
			[string]$hostName = $item.HostName

			switch ($status) {
				($START_HOST) { 
					### Must stop the BizTalk Host instance before start
					if ($item.ServiceState -eq 1) { 
						$changeStatus = $item.Start() 
						if($changeStatus.ReturnValue -eq $null) { WriteLog "INFO" "Started HostInstance '$hostName' in '$computerName'" $SCRIPTNAME } 					
					}
					else { WriteLog "INFO"  "Must stop the BizTalk Host instance '$hostName' before start" -fore Yellow -back blue }
				}
				($STOP_HOST) { 
					### Must start the BizTalk Host instance before stop
					if ($item.ServiceState -eq 4) { 
						$changeStatus = $item.Stop() 
						if($changeStatus.ReturnValue -eq $null) { WriteLog "INFO" "Stoped HostInstance '$hostName' in '$computerName'" $SCRIPTNAME } 					
					}
					else { WriteLog "INFO" "Must start the BizTalk Host instance '$hostName' before stop" $SCRIPTNAME }
				}
				default { WriteLog "INFO" "No Status received." $SCRIPTNAME }
			} 
		}	
	}
	catch{ 
        $ErrorMessage = $_.Exception.Message
        $FailedItem = $_.Exception.ItemName
		WriteLog "ERROR" "[ChangeStatusBizTalkHost] $FailedItem. The error message was $ErrorMessage" $SCRIPTNAME
		Continue 
	}
}


##############################################################################################
# Script to properly configure the BizTalk Server environment according to some of the 
# best practices by separate sending, receiving, processing, and tracking functionality 
# into multiple hosts.
#
# Author: Sandro Pereira
##############################################################################################
[void][System.reflection.Assembly]::LoadWithPartialName("Microsoft.BizTalk.ExplorerOM")

function GetBTSConnectionString
{
    $group = Get-WmiObject MSBTS_GroupSetting -n root\MicrosoftBizTalkServer
    $dbName = $group.MgmtDBName
    $server = $group.MgmtDBServerName
    [System.String]::Concat("server=", $server, ";database=", $dbName, ";Integrated Security=SSPI")
}

#############################################################
# This function will create a new BizTalk Host
# HostType: In-process	1, Isolated	2
#############################################################
function CreateBizTalkHost{
	param([Parameter(Mandatory=$true)][string]$hostName, 
			[Parameter(Mandatory=$true)][int]$hostType, 
			[Parameter(Mandatory=$true)][string]$ntGroupName, 
			[Parameter(Mandatory=$true)][bool]$authTrusted, 
			[Parameter(Mandatory=$true)][bool]$isTrackingHost, 
			[Parameter(Mandatory=$true)][bool]$is32BitOnly)

    try
    {
        [System.Management.ManagementObject]$objHostSetting = ([WmiClass]"root/MicrosoftBizTalkServer:MSBTS_HostSetting").CreateInstance()

        $objHostSetting["Name"] = $hostName
        $objHostSetting["HostType"] = $hostType
        $objHostSetting["NTGroupName"] = $ntGroupName
        $objHostSetting["AuthTrusted"] = $authTrusted
        $objHostSetting["HostTracking"] = $isTrackingHost
		$objHostSetting["IsHost32BitOnly"] = $is32BitOnly 
        
		$putOptions = new-Object System.Management.PutOptions
        $putOptions.Type = [System.Management.PutType]::CreateOnly;

        [Type[]] $targetTypes = New-Object System.Type[] 1
        $targetTypes[0] = $putOptions.GetType()

        $sysMgmtAssemblyName = "System.Management"
        $sysMgmtAssembly = [System.Reflection.Assembly]::LoadWithPartialName($sysMgmtAssemblyName)
        $objHostSettingType = $sysMgmtAssembly.GetType("System.Management.ManagementObject")

        [Reflection.MethodInfo] $methodInfo = $objHostSettingType.GetMethod("Put", $targetTypes)
        [void]$methodInfo.Invoke($objHostSetting, $putOptions)
		
		WriteLog "INFO" "Host $hostName was successfully created" $SCRIPTNAME
    }
    catch [System.Management.Automation.RuntimeException]
    {
		if ($_.Exception.Message.Contains("Another BizTalk Host with the same name already exists in the BizTalk group.") -eq $true)
        {
			WriteLog "ERROR" "$hostName can't be created because another BizTalk Host with the same name already exists in the BizTalk group." $SCRIPTNAME
        }
		else{
        	WriteLog "ERROR" "$hostName host could not be created: $_.Exception.ToString()" $SCRIPTNAME
		}
    }
}

#############################################################
# This function will update an existent BizTalk Host
# HostType: Invalid: 0, In-process:	1, Isolated: 2
#############################################################
function UpdateBizTalkHost{
	param([Parameter(Mandatory=$true)][string]$hostName, 
			[Parameter(Mandatory=$true)][int]$hostType, 
			[Parameter(Mandatory=$true)][string]$ntGroupName, 
			[Parameter(Mandatory=$true)][bool]$authTrusted, 
			[Parameter(Mandatory=$true)][bool]$isTrackingHost, 
			[Parameter(Mandatory=$true)][bool]$is32BitOnly,
			[Parameter(Mandatory=$true)][bool]$isDefaultHost)

    try
    {
        [System.Management.ManagementObject]$objHostSetting = ([WmiClass]"root/MicrosoftBizTalkServer:MSBTS_HostSetting").CreateInstance()

        $objHostSetting["Name"] = $hostName
        $objHostSetting["HostType"] = $hostType
        $objHostSetting["NTGroupName"] = $ntGroupName
        $objHostSetting["AuthTrusted"] = $authTrusted
        $objHostSetting["IsHost32BitOnly"] = $is32BitOnly 
        $objHostSetting["HostTracking"] = $isTrackingHost
		$objHostSetting["IsDefault"] = $isDefaultHost

        $putOptions = new-Object System.Management.PutOptions
        $putOptions.Type = [System.Management.PutType]::UpdateOnly; # This tells WMI it's an update.

        [Type[]] $targetTypes = New-Object System.Type[] 1
        $targetTypes[0] = $putOptions.GetType()

        $sysMgmtAssemblyName = "System.Management"
        $sysMgmtAssembly = [System.Reflection.Assembly]::LoadWithPartialName($sysMgmtAssemblyName)
        $objHostSettingType = $sysMgmtAssembly.GetType("System.Management.ManagementObject")

        [Reflection.MethodInfo] $methodInfo = $objHostSettingType.GetMethod("Put", $targetTypes)
        $methodInfo.Invoke($objHostSetting, $putOptions)
		
		WriteLog "INFO" "Host $hostName was successfully updated" $SCRIPTNAME
    }
    catch [System.Management.Automation.RuntimeException]
    {
        WriteLog "ERROR" "$hostName host could not be updated: $_.Exception.ToString()" $SCRIPTNAME
    }
}

#############################################################
# This function will create a new BizTalk Host Instance
#############################################################
function CreateBizTalkHostInstance{
	param([Parameter(Mandatory=$true)][string]$hostName,
			[Parameter(Mandatory=$true)][string]$serverName,
			[Parameter(Mandatory=$true)][string]$username,
			[Parameter(Mandatory=$true)][string]$password)

    try
    {
        [System.Management.ManagementObject]$objServerHost = ([WmiClass]"root/MicrosoftBizTalkServer:MSBTS_ServerHost").CreateInstance()

        $objServerHost["HostName"] = $hostName
        $objServerHost["ServerName"] = $serverName
        [void]$objServerHost.Map()

        [System.Management.ManagementObject]$objHostInstance = ([WmiClass]"root/MicrosoftBizTalkServer:MSBTS_HostInstance").CreateInstance()

        $name = "Microsoft BizTalk Server " + $hostName + " " + $serverName
        $objHostInstance["Name"] = $name
        [void]$objHostInstance.Install($username, $password, $true)

		WriteLog "INFO" "HostInstance $hostName was mapped and installed successfully. Mapping created between Host: $hostName and Server: $Server);" $SCRIPTNAME
    }
    catch [System.Management.Automation.RuntimeException]
    {
		if ($_.Exception.Message.Contains("Another object with the same key properties already exists.") -eq $true)
        {
			WriteLog "ERROR" "$hostName host instance can't be created because another object with the same key properties already exists." $SCRIPTNAME
        }
		else{
        	WriteLog "ERROR" "$hostName host instance on server $Server could not be created: $_.Exception.ToString()" $SCRIPTNAME
		}
    }
}

#############################################################
# This function will delete an existente host handlers 
# in the adapters.
# [direction]: 'Receive','Send'
#############################################################
function DeleteBizTalkAdapterHandler{
	param([Parameter(Mandatory=$true)][string]$adapterName,
			[Parameter(Mandatory=$true)][ValidateSet("Receive","Send")][string]$direction,
			[Parameter(Mandatory=$true)][string]$hostName)

	try
    {
		if($direction -eq 'Receive')
		{
			[System.Management.ManagementObject]$objHandler = get-wmiobject 'MSBTS_ReceiveHandler' -namespace 'root\MicrosoftBizTalkServer' -filter "HostName='$hostName' AND AdapterName='$adapterName'"
	        $objHandler.Delete()
		}
		else
		{
			[System.Management.ManagementObject]$objHandler = get-wmiobject 'MSBTS_SendHandler2' -namespace 'root\MicrosoftBizTalkServer' -filter "HostName='$hostName' AND AdapterName='$adapterName'"
	        $objHandler.Delete()
		}
    
		WriteLog "INFO" "$direction handler for $adapterName / $hostName was successfully deleted" $SCRIPTNAME
    }
    catch [System.Management.Automation.RuntimeException]
    {
        if ($_.Exception.Message -eq "You cannot call a method on a null-valued expression.")
        {
			WriteLog "ERROR" "$adapterName $direction Handler for $hostName does not exist" $SCRIPTNAME
        }
        elseif ($_.Exception.Message.IndexOf("Cannot delete a receive handler that is used by") -ne -1)
        {
			WriteLog "ERROR" "$adapterName $direction Handler for $hostName is in use and can't be deleted." $SCRIPTNAME
        }
		elseif ($_.Exception.Message.IndexOf("Cannot delete a send handler that is used by") -ne -1)
        {
			WriteLog "ERROR" "$adapterName $direction Handler for $hostName is in use and can't be deleted." $SCRIPTNAME
        }
		elseif ($_.Exception.Message.IndexOf("Cannot delete this object since at least one receive location is associated with it") -ne -1)
        {
			WriteLog "ERROR" "$adapterName $direction Handler for $hostName is in use by at least one receive location and can't be deleted." $SCRIPTNAME
        }
        else
        {
            WriteLog "ERROR" "$adapterName $direction Handler for $hostName could not be deleted: $_.Exception.ToString()" $SCRIPTNAME
        }
    }
}

#############################################################
# This function will create a handler for a specific 
# adapter on the new host, so these get used for processing.
# [direction]: 'Receive','Send'
#############################################################
function CreateBizTalkAdapterHandler{
	param([Parameter(Mandatory=$true)][string]$adapterName,
			[Parameter(Mandatory=$true)][ValidateSet("Receive","Send")][string]$direction,
			[Parameter(Mandatory=$true)][string]$hostName,
			[Parameter(Mandatory=$true)][string]$originalDefaulHostName,
			[Parameter(Mandatory=$true)][boolean]$isDefaultHandler,
			[Parameter(Mandatory=$true)][boolean]$removeOriginalHostInstance)

	if($direction -eq 'Receive')
	{
		[System.Management.ManagementObject]$objAdapterHandler = ([WmiClass]"root/MicrosoftBizTalkServer:MSBTS_ReceiveHandler").CreateInstance()
		$objAdapterHandler["AdapterName"] = $adapterName
	    $objAdapterHandler["HostName"] = $hostName
	}
	else
	{
		[System.Management.ManagementObject]$objAdapterHandler = ([WmiClass]"root/MicrosoftBizTalkServer:MSBTS_SendHandler2").CreateInstance()
		$objAdapterHandler["AdapterName"] = $adapterName
	    $objAdapterHandler["HostName"] = $hostName
	    $objAdapterHandler["IsDefault"] = $isDefaultHandler
	}
		
    try
    {
        $putOptions = new-Object System.Management.PutOptions
        $putOptions.Type = [System.Management.PutType]::CreateOnly;

        [Type[]] $targetTypes = New-Object System.Type[] 1
        $targetTypes[0] = $putOptions.GetType()

        $sysMgmtAssemblyName = "System.Management"
        $sysMgmtAssembly = [System.Reflection.Assembly]::LoadWithPartialName($sysMgmtAssemblyName)
        $objAdapterHandlerType = $sysMgmtAssembly.GetType("System.Management.ManagementObject")

        [Reflection.MethodInfo] $methodInfo = $objAdapterHandlerType.GetMethod("Put", $targetTypes)
        [void]$methodInfo.Invoke($objAdapterHandler, $putOptions)

        WriteLog "INFO" "$adapterName $direction Handler for $hostName was successfully created" $SCRIPTNAME
    }
    catch [System.Management.Automation.RuntimeException]
    {
		if ($_.Exception.Message.Contains("The specified BizTalk Host is already a receive handler for this adapter.") -eq $true)
        {
			WriteLog "ERROR" "$hostName is already a $direction Handler for $adapterName adapter."  $SCRIPTNAME
        }
		elseif($_.Exception.Message.Contains("The specified BizTalk Host is already a send handler for this adapter.") -eq $true)
        {
			WriteLog "ERROR" "$hostName is already a $direction Handler for $adapterName adapter." $SCRIPTNAME
        }
		else {
        	WriteLog "ERROR" "$adapterName $direction Handler for $hostName could not be created: $_.Exception.ToString()" $SCRIPTNAME
		}
    }



    if($direction -eq 'Receive')
	{
        # Configure all Existing Receive Ports with the default adapter
        if($removeOriginalHostInstance)
        {
            $questionResultDAConf = $windowsShell.popup("Do you want to configure existing Receive locations handlers for $adapterName adapter?", 
						          0,"No, leave has is",4)
 	
            If ($questionResultDAConf -eq 6) {
	            ConfigureBizTalkAdapterReceiveHandlerInExistingReceiveLocations $adapterName $hostName
            }
        }
	}
	else
	{
        # Configure all Existing Receive Ports with the default adapter
        if($isDefaultHandler)
        {
            $questionResultDAConf = $windowsShell.popup("Do you want to configure existing Send Port handlers for $adapterName adapter?", 
						          0,"No, leave has is",4)
 	
            If ($questionResultDAConf -eq 6) {
	            ConfigureBizTalkAdapterSendHandlerInExistingSendPorts $adapterName $hostName
            }
        }
	}
	
	if($removeOriginalHostInstance)
	{
		DeleteBizTalkAdapterHandler $adapterName $direction $originalDefaulHostName
	}
}


#############################################################
# This function will create a handler for a specific 
# adapter on the new host, so these get used for processing.
# [direction]: 'Receive','Send'
#############################################################
function ConfigureBizTalkAdapterReceiveHandlerInExistingReceiveLocations{
	param([Parameter(Mandatory=$true)][string]$adapterName, 
			[Parameter(Mandatory=$true)][string]$defaulHostInstanceName)

	$catalog = New-Object Microsoft.BizTalk.ExplorerOM.BtsCatalogExplorer
	$catalog.ConnectionString = GetBTSConnectionString

    # Let's look for receive handlers associated with the Adapter
    foreach ($handler in $catalog.ReceiveHandlers)
    {
         # if is a the correct Adapter Receive Handler
        if ($handler.TransportType.Name -eq $adapterName)
        {
            if($handler.Name -eq $defaulHostInstanceName)
            {
                foreach($receivePort in $catalog.ReceivePorts)
                {
                    # For each receive location in your environment
                    foreach($recLocation in $receivePort.ReceiveLocations)
                    {
                         # In this case I want only Receive location that are using SQL Adapter
                        if($recLocation.ReceiveHandler.TransportType.Name -eq $adapterName)
                        {
                            $recLocation.ReceiveHandler = $handler
                        }
                    }
                }
            }
        }
    }
    
    $catalog.SaveChanges()
}


function ConfigureBizTalkAdapterSendHandlerInExistingSendPorts{
	param([Parameter(Mandatory=$true)][string]$adapterName,
			[Parameter(Mandatory=$true)][string]$defaulHostInstanceName)

	$catalog = New-Object Microsoft.BizTalk.ExplorerOM.BtsCatalogExplorer
	$catalog.ConnectionString = GetBTSConnectionString

    # Let's look for send handlers associated with Adapter configured in the send port
    foreach ($handler in $catalog.SendHandlers)
    {
        # if the Send Handler is associated with the Adapter configured in the send port
        if ($handler.TransportType.Name -eq $adapterName)
        {
            if($handler.Name -eq $defaulHostInstanceName)
            {
                foreach($SendPort in $catalog.SendPorts)
                {
                    # For each receive location in your environment
                    if($sendPort.IsDynamic -eq $False)
                    {
                        if($sendPort.PrimaryTransport.TransportType.Name -eq $adapterName)
                        {
                            $sendPort.PrimaryTransport.SendHandler = $handler
                        }
                    }
                    if($sendPort.IsDynamic -eq 'True')
                    {
                        # Changing the default send handlers of the dynamic port
                        $sendPort.SetSendHandler($adapterName, $defaulHostInstanceName)
                    }
                }
            }
        }
    }

    $catalog.SaveChanges()
}

