﻿$SERVICESCONFIGPATH = "$CURRENTFOLDER\..\Config\Services.config"
$CONFIGSERVICES = GetConfigContent $SERVICESCONFIGPATH

$RULEENGINE_SERVICE = "RuleEngineUpdateService"
$SSO_SERVICE = "ENTSSO"
$BIZTALK_APP_SERVICE = "BTSSvc`$BizTalkServerApplication" ### Use ` character

$START_STATUS = "Start"
$STOP_STATUS = "Stop"
$RESTART_STATUS = "Restart"

function GetRuleEngineSSOServices{
	param([Parameter(Mandatory=$true)][Xml]$xmlDoc)

    [string]$nameSpace = "http://iac/services"
    [string]$xPath = "/tns:Services/tns:Service[tns:Name[text()='$RULEENGINE_SERVICE' or text()='$SSO_SERVICE']]"
    $nodesServices = GetXmlNodes $xmlDoc $xPath $nameSpace
    Write-Output $nodesServices
}

function ChangeStatusService{
	param([Parameter(Mandatory=$true)]$serviceName, 
			[Parameter(Mandatory=$true)]$computerName, 
			[Parameter(Mandatory=$true)]$ipAdress, 
			[Parameter(Mandatory=$true)][string]$status
			)
	
	switch ($status) {
		($START_STATUS) { 
			WriteLog "INFO" ("Starting service {0} in computer {1}" -f $serviceName, $computerName) $SCRIPTNAME
			Get-Service -ComputerName $computerName -Name $serviceName | Start-Service #-ErrorAction Stop #-Verbose
		}
		($STOP_STATUS) { 
			WriteLog "INFO" ("Stopping service {0} in computer {1}" -f $serviceName, $computerName) $SCRIPTNAME
			Get-Service -ComputerName $computerName -Name $serviceName | Stop-Service -Force #-PassThru -ErrorAction Stop #-Verbose
		}
		($RESTART_STATUS) { 
			WriteLog "INFO" ("Restarting service {0} in computer {1}" -f $serviceName, $computerName) $SCRIPTNAME
			Get-Service -ComputerName $computerName -Name $serviceName | Restart-Service -Force #-PassThru -ErrorAction Stop #-Verbose
		}
		default { WriteLog "INFO" "No Status received." $SCRIPTNAME }
	}
}

function ChangeCredentialsServices{
	param([Parameter(Mandatory=$true)][string]$serviceName, 
			[Parameter(Mandatory=$true)][string]$computerName, 
			[Parameter(Mandatory=$true)][string]$ipAdress,
			[Parameter(Mandatory=$true)][string]$serviceUser,
			[Parameter(Mandatory=$true)][string]$servicePass,
			[Parameter(Mandatory=$true)]$winCredentials
			)

	$params = @{ 'Class' = 'Win32_Service'; 'ComputerName' = $ipAdress; 'Filter' = "name = '$serviceName'"}
	if($env:computername -ne $computerName) { $params.Add('Credential', $winCredentials) }
	
	Try{
		$winServices = Get-WmiObject @params 
		
		$changeStatus = $winServices.change($null,$null,$null,$null,$null,$null,$serviceUser,$servicePass,$null,$null,$null)
		Start-Sleep -m 500
		if($changeStatus.ReturnValue -eq "0") {WriteLog "INFO" "User Name successfully for the service '$serviceName' in '$computerName'" $SCRIPTNAME } 	
	}
	Catch{
        $ErrorMessage = $_.Exception.Message
        $FailedItem = $_.Exception.ItemName
		WriteLog "ERROR" "[ChangeCredentialsServices] $FailedItem. The error message was $ErrorMessage" $SCRIPTNAME
	}				
}
