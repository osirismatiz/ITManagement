$APPPOOLCONFIGPATH = "$CURRENTFOLDER\..\Config\AppPools.config"
$CONFIGAPPPOOL = GetConfigContent $APPPOOLCONFIGPATH

function GetAppPoolConfig{
	param([Parameter(Mandatory=$true)][Xml]$xmlDoc)

    [string]$nameSpace = "http://iac/apppools"
	[string]$xPath = "/tns:AppPools/tns:AppPool"
    $nodesServices = GetXmlNodes $xmlDoc $xPath $nameSpace
    #$nodesServices | Foreach { Write-Host $_.Node.Name}
    Write-Output $nodesServices
}

function ChangeCredentialAppPoolsByUserName{
	param([Parameter(Mandatory=$true)][string]$computerName, 
		  [Parameter(Mandatory=$true)][string]$currentUserName,
		  [Parameter(Mandatory=$true)][string]$newUserName,
		  [Parameter(Mandatory=$true)][string]$newPassword
		 )

	Try{
		#$newPassword
		if(-not(Get-Module -name "WebAdministration")) { Import-Module "WebAdministration" }
		#$appPoolList = Get-ItemProperty IIS:\AppPools\* -name processModel | Where { $_.username -eq $currentUserName } 
		$appPoolList = Get-ItemProperty "WebAdministration::\\$computerName\AppPools\*" -name processModel | Where { $_.username -eq $currentUserName } 
		
		if($appPoolList -eq $null) { Continue }
		
		foreach($appPool in $appPoolList)
		{
			Try{ 
				$appName = $appPool.PSChildName
				$myAppPool = Get-WmiObject -Namespace root\WebAdministration -Class ApplicationPool -Filter "Name = '$appName'"
				
				Set-ItemProperty -Path IIS:\AppPools\$($appName) -name processModel -value @{ userName = $newUserName; password = $newPassword; identitytype = 3}
				WriteLog "INFO" "The AppPool '$appName' user modified successfully" $SCRIPTNAME
			}
			Catch{
				$ErrorMessage = $_.Exception.Message
				$FailedItem = $_.Exception.ItemName
				WriteLog "ERROR" "[ChangeCredentialAppPools: Change: ] $FailedItem. The error message was $ErrorMessage" $SCRIPTNAME
				Continue
			}
		} 
	}
	Catch{
		$ErrorMessage = $_.Exception.Message
		$FailedItem = $_.Exception.ItemName
		WriteLog "ERROR" "[ChangeCredentialAppPools] $FailedItem. The error message was $ErrorMessage" $SCRIPTNAME
	}
}

function StopAppPoolsByUserName{
	param([Parameter(Mandatory=$true)][string]$computerName, [Parameter(Mandatory=$true)][string]$currentUserName)
	
	Try{
		if(-not(Get-Module -name "WebAdministration")) { Import-Module "WebAdministration" }
		#$appPoolList = Get-ItemProperty IIS:\AppPools\* -name processModel | Where { $_.username -eq $currentUserName } 
		$appPoolList = Get-ItemProperty "WebAdministration::\\$computerName\AppPools\*" -name processModel | Where { $_.username -eq $currentUserName } 
		
		if($appPoolList -eq $null) { Continue }
		
		foreach($appPool in $appPoolList) { 
			Try{
				$appName = $appPool.PSChildName
				$myAppPool = Get-WmiObject -Namespace root\WebAdministration -Class ApplicationPool -Filter "Name = '$appName'"
				#$appPool.password
				$statusApp = $myAppPool.GetState()
				if($statusApp.ReturnValue -eq 1) { # Status 1 ---> RUN, Status 3 ---> STOP
					$myAppPool.Stop()
					WriteLog "INFO" "The AppPool '$appName' stop successfully" $SCRIPTNAME
				}
				else { WriteLog "INFO" "The AppPool '$appName' is stopped" $SCRIPTNAME }
			}
			Catch{
				$ErrorMessage = $_.Exception.Message
				$FailedItem = $_.Exception.ItemName
				WriteLog "ERROR" "[StopAppPools: Stop: ] $FailedItem. The error message was $ErrorMessage" $SCRIPTNAME 
				Continue
			}
		}
	}
	Catch{
		$ErrorMessage = $_.Exception.Message
		$FailedItem = $_.Exception.ItemName
		WriteLog "ERROR" "[StopAppPools] $FailedItem. The error message was $ErrorMessage" $SCRIPTNAME 
	}
}

function StartAppPoolsByUserName{
	param([Parameter(Mandatory=$true)][string]$computerName, [Parameter(Mandatory=$true)][string]$currentUserName)

	Try{
		if(-not(Get-Module -name "WebAdministration")) { Import-Module "WebAdministration" }
		#$appPoolList = Get-ItemProperty IIS:\AppPools\* -name processModel | Where { $_.username -eq $currentUserName } 
		$appPoolList = Get-ItemProperty "WebAdministration::\\$computerName\AppPools\*" -name processModel | Where { $_.username -eq $currentUserName } 
		
		if($appPoolList -eq $null) { Continue }
		
		foreach($appPool in $appPoolList) { 
			Try{
				$appName = $appPool.PSChildName
				$myAppPool = Get-WmiObject -Namespace root\WebAdministration -Class ApplicationPool -Filter "Name = '$appName'"
				$statusApp = $myAppPool.GetState()
				if($statusApp.ReturnValue -eq 3) { # Status 1 ---> RUN, Status 3 ---> STOP
					$myAppPool.Start()
					WriteLog "INFO" "The AppPool '$appName' start successfully" $SCRIPTNAME 
				} 
				else { WriteLog "INFO" "The AppPool '$appName' is started" $SCRIPTNAME }
			}
			Catch{
				$ErrorMessage = $_.Exception.Message
				$FailedItem = $_.Exception.ItemName
				WriteLog "ERROR" "[StartAppPools: Start: ] $FailedItem. The error message was $ErrorMessage" $SCRIPTNAME 
				Continue
			}
		}
	}
	Catch{
		$ErrorMessage = $_.Exception.Message
		$FailedItem = $_.Exception.ItemName
		WriteLog "ERROR" "[StartAppPools] $FailedItem. The error message was $ErrorMessage" $SCRIPTNAME
	}
}
