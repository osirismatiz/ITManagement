﻿$SERVERSCONFIGPATH = "$CURRENTFOLDER\..\Config\Servers.config"
$CONFIGSERVERS = GetConfigContent $SERVERSCONFIGPATH

function GetServersList{
	param([Parameter(Mandatory=$true)][Xml]$xmlDoc, 
			[Parameter(Mandatory=$true)][string]$envName, 
			[Parameter(Mandatory=$true)][string]$farmName
			)

    [string]$nameSpace = "http://iac/servers"
    [string]$xPath = "/tns:Servers/tns:Environment[@Name='$envName']/tns:Farm[@Name='$farmName']/tns:Server"
    $nodeServers = GetXmlNodes $xmlDoc $xPath $nameSpace
    Write-Output $nodeServers
}

function GetServersByXPath{
	param([Parameter(Mandatory=$true)][Xml]$xmlDoc, [Parameter(Mandatory=$true)][string]$xPath)

    [string]$nameSpace = "http://iac/servers"
    $nodesServers = GetXmlNodes $xmlDoc $xPath $nameSpace
    Write-Output $nodesServers
}
