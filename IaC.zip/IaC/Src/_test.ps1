[CmdletBinding()]
param(
[Parameter(Position=0,Mandatory=$true,HelpMessage="Name of the computer to test",
ValueFromPipeline=$True,ValueFromPipelineByPropertyName=$true)]
[Alias('CN','__SERVER','IPAddress','Server')]
[System.String]$ComputerInfo
)
 
process {

$email=$null
$splitparam= $ComputerInfo.split(":")
$Service=$splitparam[0]
$Computer=$splitparam[1]
$Port=$splitparam[2] 
$Connection = New-Object Net.Sockets.TcpClient
 
try {
 
$Connection.Connect($Computer,$Port)
 
if ($Connection.Connected) {
$Response = "Open"
$Connection.Close()
}
 
}
 
catch [System.Management.Automation.MethodInvocationException]
 
{
$Response = "Closed / Filtered"
$down+=$computer+":"+$Port + "`n"
}
 
$Connection = $null
 
$MYObject = "" | Select-Object Service,Computer,Port,Response
$MYObject.Service = $Service
$MYObject.Computer = $Computer
$MYObject.Port = $Port
$MYObject.Response = $Response
$MYObject
}