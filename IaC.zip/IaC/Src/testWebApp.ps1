Clear-Host

#$credentials = Get-Credential -Credential "SLPAlRT_LAB2016@ACEINA"

[string[]]$webAppList = @(
"http://172.25.104.157/ESB.UDDI.Service/UDDIService.asmx", 
"http://172.25.104.157/ESB.TransformServices.WCF/TransformationService.svc", 
"http://172.25.104.157/ESB.TransformServices/TransformationService.asmx",
"http://172.25.104.157/ESB.ResolverServices.WCF/ResolverService.svc",
"http://172.25.104.157/ESB.ResolverServices/ResolverService.asmx",
"http://172.25.104.157/esb.portal/Default.aspx",
"http://172.25.104.157/ESB.ItineraryServices.WCF/ProcessItinerary.svc",
"http://172.25.104.157/ESB.ItineraryServices.Response.WCF/ProcessItinerary.svc",
"http://172.25.104.157/ESB.ItineraryServices.Response/ProcessItinerary.asmx",
"http://172.25.104.157/ESB.ItineraryServices.Generic.WCF/ProcessItinerary.svc",
"http://172.25.104.157/ESB.ItineraryServices.Generic.Response.WCF/ProcessItinerary.svc",
"http://172.25.104.157/ESB.ItineraryServices/ProcessItinerary.asmx",
"http://172.25.104.157/ESB.Exceptions.Service/ExceptionService.svc",
"http://172.25.104.157/ESB.ExceptionHandlingServices.WCF/ExceptionHandling.svc",
"http://172.25.104.157/ESB.ExceptionHandlingServices/ExceptionHandling.asmx",
"http://172.25.104.157/ESB.BizTalkOperationsService/Operations.asmx",
"http://172.25.104.157/ESB.BAM.Service/BAMService.svc",
"http://172.25.104.157/BAM/default.aspx",
"http://172.25.104.157/BAM/BAMQueryService/BamQueryService.asmx",
"http://172.25.104.157/BAM/BAMManagementService/BamManagementService.asmx"
);

$milliseconds = $null;
foreach ($url in $webAppList) { 
	Try {
		Write-Host ("Testing {0}" -f $url)
		$timeTaken = Measure-Command -Expression { $result = Invoke-WebRequest -Uri $url  } # -UseBasicParsing -DisableKeepAlive -ContentType 'text/xml'  -Credential $credentials | Select-Object StatusDescription  
		$milliseconds = $timeTaken.TotalMilliseconds
		$milliseconds = [Math]::Round($milliseconds, 0)
		"This took $milliseconds ms to execute"		
		Write-Host ("OK   : {0}" -f $result.StatusCode) -F white -B blue
	}
    catch [Net.WebException]
    {
		"This took $milliseconds ms to execute"	
        Write-Host ("Error: {0}" -f [int]$_.Exception.Response.StatusCode) -F red -B yellow
    }
}


