﻿<#
    Date       : 2019-03-07
    Author     : Osiris Matiz Zapata
    Name       : ChangeServicePassword
    Description: Change passwords to all services list 
#>

[CmdletBinding()]
param ([Parameter(Mandatory=$true)][string]$Environment, [Parameter(Mandatory=$true)][string]$Farm)

Set-ExecutionPolicy -ExecutionPolicy RemoteSigned -Force
Get-ExecutionPolicy

[System.GC]::Collect()
Clear-Host

$SCRIPTNAME = $MyInvocation.MyCommand.Name
$host.ui.rawui.windowtitle = $SCRIPTNAME

$CURRENTFOLDER = Split-Path -parent $MyInvocation.MyCommand.Path
cd $CURRENTFOLDER

###Import Modules
. ..\Modules\ModuleXML.ps1 
. ..\Modules\ModuleLogs.ps1 
. ..\Modules\ModuleServers.ps1 
. ..\Modules\ModuleServices.ps1 
. ..\Modules\ModuleBizTalk.ps1 

WriteLog "INFO" "***** Start Script *****" $SCRIPTNAME
WriteLog "INFO" ("Current Folder is:'{0}'" -f $CURRENTFOLDER) $SCRIPTNAME

function Main{
	param([Parameter(Mandatory=$true)][string]$environmentName, [Parameter(Mandatory=$true)][string]$farmName)

    try{ 
		$serversList = GetServersList $CONFIGSERVERS $environmentName $farmName 

        #Obtener la Lista de Servicios RuleEngine y SSO
        $RuleEngineSSOServices = GetRuleEngineSSOServices $CONFIGSERVICES 
		
		#Suministrar las Credenciales de una cuenta con provilegios de Administrador 
        $adminCredentials = Get-Credential -credential "Administrator_User"
		
        foreach($server in $serversList) { 
			[string]$serverName = $server.Node.Name
			[string]$ipServer = $server.Node.IPAdress
				
			WriteLog "INFO" ("Environment:'{0}' `tFarm:'{1}' `tServer:'{2}' IPAdress:'{3}'" -f  $environmentName, $farmName, $serverName, $ipServer) $SCRIPTNAME
			WriteLog "INFO" "---------------------------------------------------------------------------------------------------" $SCRIPTNAME
			
			foreach ($service in $RuleEngineSSOServices) { 
				[string]$serviceName = $service.Node.Name
				[string]$serviceUser = $service.Node.Logon.UserName
				[string]$servicePass = $service.Node.Logon.Password

				ChangeServicesCredentials $serviceName $serverName $ipServer $serviceUser $servicePass $adminCredentials 
			}			
        }
	}
	catch{ 
        $ErrorMessage = $_.Exception.Message
        $FailedItem = $_.Exception.ItemName
		WriteLog "ERROR" "[Main] $FailedItem. The error message was $ErrorMessage" $SCRIPTNAME
	}

	remove-variable * -scope:Global -ErrorAction:SilentlyContinue
}

Main $Environment $Farm
WriteLog "INFO" "***** End Script   *****" $SCRIPTNAME
