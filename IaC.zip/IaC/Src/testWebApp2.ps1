Clear-Host

#$credentials = Get-Credential -Credential "SLPAlRT_LAB2016@ACEINA"

[string[]]$webAppList = @(
"http://172.25.104.157/ESB.UDDI.Service/UDDIService.asmx?wsdl", 
"http://172.25.104.157/ESB.TransformServices.WCF/TransformationService.svc?wsdl", 
"http://172.25.104.157/ESB.TransformServices/TransformationService.asmx?wsdl",
"http://172.25.104.157/ESB.ResolverServices.WCF/ResolverService.svc?wsdl",
"http://172.25.104.157/ESB.ResolverServices/ResolverService.asmx?wsdl",
"http://172.25.104.157/esb.portal/Default.aspx",
"http://172.25.104.157/ESB.ItineraryServices.WCF/ProcessItinerary.svc?wsdl",
"http://172.25.104.157/ESB.ItineraryServices.Response.WCF/ProcessItinerary.svc?wsdl",
"http://172.25.104.157/ESB.ItineraryServices.Response/ProcessItinerary.asmx?wsdl",
"http://172.25.104.157/ESB.ItineraryServices.Generic.WCF/ProcessItinerary.svc?wsdl",
"http://172.25.104.157/ESB.ItineraryServices.Generic.Response.WCF/ProcessItinerary.svc?wsdl",
"http://172.25.104.157/ESB.ItineraryServices/ProcessItinerary.asmx?wsdl",
"http://172.25.104.157/ESB.Exceptions.Service/ExceptionService.svc?wsdl",
"http://172.25.104.157/ESB.ExceptionHandlingServices.WCF/ExceptionHandling.svc?wsdl",
"http://172.25.104.157/ESB.ExceptionHandlingServices/ExceptionHandling.asmx?wsdl",
"http://172.25.104.157/ESB.BizTalkOperationsService/Operations.asmx?wsdl",
"http://172.25.104.157/ESB.BAM.Service/BAMService.svc?wsdl",
"http://172.25.104.157/BAM/default.aspx",
"http://172.25.104.157/BAM/BAMQueryService/BamQueryService.asmx?wsdl",
"http://172.25.104.157/BAM/BAMManagementService/BamManagementService.asmx?wsdl"
);

$milliseconds = $null;
foreach ($url in $webAppList) { 
	Try {
	
		#$timeTaken = Measure-Command -Expression { 
			$HTTP_Request = [System.Net.WebRequest]::Create($url);
			$HTTP_Request.Credentials = New-Object System.Net.NetworkCredential('ACEINA\SLPWEB_LAB2016', '05b1ZT4lK$o19#');
			$HTTP_Response = $HTTP_Request.GetResponse();
			$HTTP_Status = [int]$HTTP_Response.StatusCode;
			$HTTP_Response.Close();
		#} 
		#$milliseconds = $timeTaken.TotalMilliseconds
		#$milliseconds = [Math]::Round($milliseconds, 0)
		#"$milliseconds ms to execute"	
		
		#If ($HTTP_Status -eq 200) {
			Write-Host ("StatusCode: {0} {1}" -f $HTTP_Status, $url) -F white #-B Gray
			
		#}
		#Else {
		#	Write-Host ("Error: {0} {1}" -f $HTTP_Status, $url) -F red -B yellow
		#}
	}
	catch [Net.WebException]
    {
        Write-Host ("StatusCode: {0} {1}" -f ([int]$_.Exception.Response.StatusCode), $url) -F red #-B Gray
		$HTTP_Response.Close();
    }
}

